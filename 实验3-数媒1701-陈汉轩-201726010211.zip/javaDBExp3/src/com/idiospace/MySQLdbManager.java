package com.idiospace;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLdbManager {
    //定义成员变量
    public Connection conn = null;
    public Statement stmt = null;
    public ResultSet rst = null;

    //创建数据库连接对象
    public void getConnection(String url, String user, String password) {

        //加载数据库驱动
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver Error:\n" + e.toString());
            return;
        }

        //开始连接数据库
        try {
            conn = DriverManager.getConnection(url, user, password);
            if (!conn.isClosed()) {
                System.out.println("DB connection established");
            }
        } catch (SQLException e) {
            System.out.println("DB connection failed" + e.toString());
            return;
        }
    }

    //得到SQL执行对象
    public Statement getStatement () {
        try {
            stmt = conn.createStatement();
        } catch (SQLException e) {
            System.out.println(e.toString());
            return stmt = null;
        }
        return stmt;
    }


    //创建记录,即向数据库中插入数据
    public int create(String sqlCreate) {
        int nRecord = 0;
        try {
            nRecord = this.stmt.executeUpdate(sqlCreate);
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return nRecord;
    }

    //查询记录
    public boolean exists(String sqlSelect) {
        try {
            if (this.stmt.executeQuery(sqlSelect).next()) {
                return true;
            }
            return false;
        }
        catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }

    //更新记录
    public int update(String sqlUpdate) {
        int nRecord = 0;
        try {
            nRecord = this.stmt.executeUpdate(sqlUpdate);
        }
        catch(SQLException e){
            System.out.println(e.toString());
        }
        return nRecord;
    }

    //删除记录
    public int delete(String sqlDelete) {
        int nRecord = 0;
        try {
            nRecord = this.stmt.executeUpdate(sqlDelete);
        }
        catch(SQLException e){
            System.out.println(e.toString());
        }
        return nRecord;
    }

    /*
    //关闭结果集
    public void closeResultSet(ResultSet rs){
        try{
            rst.close();
        }
        catch(SQLException e){
            System.out.println(e.toString());
            return;
        }
    }
    */


    //关闭SQL语句执行对象
    public void closeStatement(){
        try{
            this.stmt.close();
            System.out.println("DB statement closed successfully");
        }
        catch(SQLException e){
            System.out.println(e.toString());
            return;
        }
    }

    //断开与数据库的连接
    public void closeConnection(){
        try{
            this.conn.close();
            System.out.println("DB connection closed successfully");
        }
        catch(SQLException e){
            System.out.println(e.toString());
            return;
        }
    }

}
