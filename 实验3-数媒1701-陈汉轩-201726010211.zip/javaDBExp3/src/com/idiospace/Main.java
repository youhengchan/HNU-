package com.idiospace;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;

public class Main {

    public static void main(String[] args) {

        MySQLdbManager dba = new MySQLdbManager();

        // 数据库信息
        String url = "jdbc:mysql://localhost:3306/jdbctest?&useSSL=false&serverTimezone=UTC";
        String user = "root";
        String password = "toor";

        dba.getConnection(url, user, password);
        dba.getStatement();

        // 创建 user 表
        String sql1 = "create table users"
                + "( "
                + "username varchar(10) not null,"
                + "pass varchar(8) not null,"
                + "primary key (username)"
                + ")";

        // 创建 person 表
        String sql2 = "CREATE TABLE person" +
                "(" +
                "username varchar(10) not null," +
                "name varchar(20) PRIMARY KEY," +
                "age int default 21, " +
                "teleno char(11) default '12345678901'," +
                "FOREIGN KEY (username) REFERENCES users(username)" +
                ")";

        // 第一步建表 users
        System.out.println("第一步建表 users");
        dba.create(sql1);
        printUserTableHeader();

        // 第一步建表 person
        System.out.println("第一步建表 person");
        dba.create(sql2);
        printPersonTableHeader();

        // 在 users 表中插入数据
        String sql3 = "INSERT INTO users VALUES('ly','123456')";
        String sql4 = "INSERT INTO users VALUES('liming', '345678')";
        String sql5 = "INSERT INTO users VALUES('test', '11111')";
        String sql6 = "INSERT INTO users VALUES('test1', '12345')";

        // 第二步 users 表插入数据
        System.out.println("第二步 users 表插入数据");
        dba.update(sql3);
        dba.update(sql4);
        dba.update(sql5);
        dba.update(sql6);
        printUserTableHeader();
        printUserTableInfo(dba);

        // 在 person 表中插入数据
        String sql7 = "INSERT INTO person(username, name) VALUES('ly', '雷力')";
        String sql8 = "INSERT INTO person(username, name, age) VALUES('liming','李明', 25)";
        String sql9 = "INSERT INTO person VALUES('test','测试用户',20,'13388449933')";


        // 第二步 person 表插入数据
        System.out.println("第二步 person 表插入数据");
        dba.update(sql7);
        dba.update(sql8);
        dba.update(sql9);
        printPersonTableHeader();
        printPersonTableInfo(dba);


        // 在 person 表中 插入/更新 5行数据
        String sql10 = "INSERT INTO person(username, name) VALUES('ly', '王五')";
        String sql11 = "INSERT INTO person(username, name) VALUES('test2', '测试用户2')";
        String sql12 = "INSERT INTO person(username, name, age) VALUES('test1','测试用户1', 33)";
        String sql13 = "INSERT INTO person VALUES('test','张三',23,'18877009966')";
        String sql14 = "INSERT INTO person(username, name) VALUES('admin', 'admin')";

        String sql15 = "UPDATE person SET username = 'ly' WHERE name = '王五'";
        String sql16 = "UPDATE person SET username = 'test2' WHERE name = '测试用户2'";
        String sql17 = "UPDATE person SET username = 'test1', age = 33 WHERE name = '测试用户1'";
        String sql18 = "UPDATE person SET username = 'test', age = 23, teleno = '18877009966' WHERE name = '张三'";
        String sql19 = "UPDATE person SET username = 'admin' WHERE name = 'admin'";

        String sql20 = "SELECT * FROM person WHERE username = ";

        String sql21 = "INSERT INTO users VALUES('ly', '888888')";
        String sql22 = "INSERT INTO users VALUES('test2', '888888')";
        String sql23 = "INSERT INTO users VALUES('test1', '888888')";
        String sql24 = "INSERT INTO users VALUES('test', '888888')";
        String sql25 = "INSERT INTO users VALUES('admin', '888888')";

        // 第三步 检查是否重复，重复则更新，非重复则插入
        System.out.println("第三步 检查是否重复，重复则更新，非重复则插入");
        if (dba.exists(sql20+"'ly'")) {
            dba.update(sql15);
        } else {
            dba.create(sql21);
            dba.create(sql10);
        }

        if (dba.exists(sql20+"'test2'")) {
            dba.update(sql16);
        } else {
            dba.create(sql22);
            dba.create(sql11);
        }

        if (dba.exists(sql20+"'test1'")) {
            dba.update(sql17);
        } else {
            dba.create(sql23);
            dba.create(sql12);
        }

        if (dba.exists(sql20+"'test'")) {
            dba.update(sql18);
        } else {
            dba.create(sql24);
            dba.create(sql13);
        }

        if (dba.exists(sql20+"'admin'")) {
            dba.update(sql19);
        } else {
            dba.create(sql25);
            dba.create(sql14);
        }

        printUserTableHeader();
        printUserTableInfo(dba);

        printPersonTableHeader();
        printPersonTableInfo(dba);

        // 第四步 删除 users/person 表中 test 打头 username
        System.out.println("第四步 删除 users/person 表中 test 打头 username");
        while (deletetest(dba.conn, "person"));
        while (deletetest(dba.conn, "users"));

        printUserTableHeader();
        printUserTableInfo(dba);

        printPersonTableHeader();
        printPersonTableInfo(dba);

        dba.closeStatement();
        dba.closeConnection();
    }

    public static void printUserTableHeader() {
        System.out.println("表users:");
        System.out.println("字段名 username                   字段名 pass");
    }

    public static void printUserTableInfo(MySQLdbManager dba) {
        String sql = "select * from users";
        try{
            ResultSet ret = dba.stmt.executeQuery(sql);
            while(ret.next()) {
                String username = ret.getString("username");
                String password = ret.getString("pass");

                System.out.print("      "+username);
                System.out.println("                         "+password);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }

    public static void printPersonTableHeader() {
        System.out.println("表person:");
        System.out.println("字段名 username        字段名 name        字段名age         字段名 teleno");
    }

    public static void printPersonTableInfo(MySQLdbManager dba) {
        String sql = "select * from person";
        try{
            ResultSet ret = dba.stmt.executeQuery(sql);
            while(ret.next()) {
                String username = ret.getString("username");
                String name = ret.getString("name");
                String age = ret.getString("age");
                String teleno = ret.getString("teleno");

                System.out.print("      "+username);
                System.out.print("           "+name);
                System.out.print("           "+age);
                System.out.println("           "+teleno);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }

    public static boolean deletetest(Connection connect, String table) {
        String sql = "select * from " + table + " ;";
        try {
            Statement stm = connect.createStatement();
            ResultSet rs = stm.executeQuery(sql);
            String deletesql;
            while (rs.next()) {
                String tempname = rs.getString("username");
                if (tempname.length() >= 4 && tempname.substring(0, 4).equals("test")) {
                    deletesql = "delete from " + table + " where username='"
                            + rs.getString("username") + "';";
                    stm.execute(deletesql);
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        }
        return false;
    }
}
