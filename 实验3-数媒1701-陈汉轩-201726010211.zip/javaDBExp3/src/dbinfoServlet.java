import com.idiospace.MySQLdbManager;

import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/dbinfoServlet")
public class dbinfoServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {

        request.setCharacterEncoding("utf-8" );
        response.setCharacterEncoding("utf-8");
        response.setHeader( "content-type",  "text/html ; charset=utf-8");

        PrintWriter printWriter = response.getWriter();

        // 首先从表单提交出的信息中解析出各个参数字符串的值
        String person_username = request.getParameter( "first" );  // 从前端拿到要查询的Person用户的名称
        String user_username = request.getParameter( "second" ); // 从前端拿到要查询的User用户名称

        try {
            // 然后调用实验2中封装好的类，将数据从user表中提取出来，显示到页面上
            MySQLdbManager dba = new MySQLdbManager();

            // 数据库信息
            String url = "jdbc:mysql://localhost:3306/jdbctest?&useSSL=false&serverTimezone=UTC";
            String user = "root";
            String password = "toor";

            dba.getConnection(url, user, password);
            dba.getStatement();

            printUserTableHeader(printWriter);
            printUserTableInfo(person_username, dba, printWriter);

            printWriter.write("\n\n\n" );

            printPersonTableHeader(printWriter);
            printPersonTableInfo(user_username, dba, printWriter);

            dba.closeStatement();
            dba.closeConnection();
            printWriter.write("\n\n显示数据完成\n" );
        } catch (Exception e) {
            printWriter.write("\n\n数据库查询操作异常\n\n" + e.toString());
        }
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doPost(request, response);
    }

    public static void printPersonTableInfo(String username, MySQLdbManager dba, PrintWriter printWriter) {
        String sql = "select * from person where username = '" + username + "'";
        try{
            ResultSet ret = dba.stmt.executeQuery(sql);
            while(ret.next()) {
                String uname = ret.getString("username");
                String name = ret.getString("name");
                String age = ret.getString("age");
                String teleno = ret.getString("teleno");

                printWriter.write("      "+uname);
                printWriter.write("           "+name);
                printWriter.write("           "+age);
                printWriter.write("           "+teleno + "\n");
            }
        } catch (SQLException e) {
            printWriter.write(e.toString());
        }
    }

    public static void printUserTableInfo(String username, MySQLdbManager dba, PrintWriter printWriter) {
        String sql = "select * from users where username= '" + username + "'";
        try{
            ResultSet ret = dba.stmt.executeQuery(sql);
            while(ret.next()) {
                String uname = ret.getString("username");
                String password = ret.getString("pass");

                printWriter.write("      "+uname);
                printWriter.write("                         "+password + "\n");
            }
        } catch (SQLException e) {
            printWriter.write(e.toString());
        }
    }

    public static void printPersonTableHeader(PrintWriter printWriter) {
        printWriter.write("----------------------------表person-----------------------------------\n");
        printWriter.write("字段名 username        字段名 name        字段名age         字段名 teleno\n");
    }

    public static void printUserTableHeader(PrintWriter printWriter) {
        printWriter.write("-------------------表users-------------------\n");
        printWriter.write("字段名 username                   字段名 pass\n");
    }
}
