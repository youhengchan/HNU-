import com.idiospace.MySQLdbManager;

import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/indexInsertServlet")
public class indexInsertServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        request.setCharacterEncoding("utf-8" );
        response.setCharacterEncoding("utf-8");
        response.setHeader( "content-type",  "text/html ; charset=utf-8");

        PrintWriter printWriter = response.getWriter();

        // 首先从表单提交出的信息中解析出各个参数字符串的值
        String username = request.getParameter( "username" );
        String name = request.getParameter( "name" );
        String age = request.getParameter( "age" );
        String telenum = request.getParameter("telenum" );

        try {
            // 然后调用实验2中封装好的类，将数据插入到数据库中
            MySQLdbManager dba = new MySQLdbManager();

            // 数据库信息
            String url = "jdbc:mysql://localhost:3306/jdbctest?&useSSL=false&serverTimezone=UTC";
            String user = "root";
            String password = "toor";

            dba.getConnection(url, user, password);
            dba.getStatement();

            // 将数据插入
            // 插入数据到 person 表之前必须将 username 添加到 user 表
            // 插入 Person 表前 先插入 User 表，将默认密码设置为 123456
            String sql1 = "INSERT INTO users(username, pass) VALUES(" + "'" + username + "', " +
                     "'123456'" + ")";
            String sql2 = "INSERT INTO person(username, name, age, teleno) VALUES(" + "'" + username + "'" +
                         "," + "'" + name + "'" + "," + age + "," + "'" + telenum + "'" + ")";
            System.out.println("sql = " + sql1);
            System.out.println("sql = " + sql2);
            dba.create(sql1);
            dba.create(sql2);
            dba.closeStatement();
            dba.closeConnection();
            printWriter.write("插入Person数据\n" + username + " " + name + " " + age + " " + telenum + '\n');
            printWriter.write("<a href=\".\\dbinfo.html\">查看数据库情况</a>");
        } catch (Exception e) {
            printWriter.write("操作异常\n" + e.toString());
            printWriter.write("<a href=\".\\dbinfo.html\">查看数据库情况</a>");
        }

    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doPost(request, response);
    }
}
