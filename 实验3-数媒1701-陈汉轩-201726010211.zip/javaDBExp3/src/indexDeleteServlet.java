import com.idiospace.MySQLdbManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/indexDeleteServlet")
public class indexDeleteServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8" );
        response.setCharacterEncoding("utf-8");
        response.setHeader( "content-type",  "text/html ; charset=utf-8");

        PrintWriter printWriter = response.getWriter();

        // 首先从表单提交出的信息中解析出各个参数字符串的值
        String username = request.getParameter( "username" );

        try {
            // 然后调用实验2中封装好的类，将数据从user表中删除
            // 这里有外键约束，需要先删除 Person 表中的对应的 username 的信息
            MySQLdbManager dba = new MySQLdbManager();

            // 数据库信息
            String url = "jdbc:mysql://localhost:3306/jdbctest?&useSSL=false&serverTimezone=UTC";
            String user = "root";
            String password = "toor";

            dba.getConnection(url, user, password);
            dba.getStatement();

            // 将数据插入
            // 删除 Users 表中内容之前必须 先删除 Person 表中的内容
            String sql1 = "delete from person where username= '" + username + "'";
            String sql2 = "delete from users where username= '" + username + "'";

            System.out.println("sql = " + sql1);
            System.out.println("sql = " + sql2);

            dba.delete(sql1);
            dba.delete(sql2);
            dba.closeStatement();
            dba.closeConnection();
            printWriter.write("删除User & Person 数据\n" + username + '\n');
            printWriter.write("<a href=\".\\dbinfo.html\">查看数据库情况</a>");
        } catch (Exception e) {
            printWriter.write("操作异常\n" + e.toString() + '\n');
            printWriter.write("<a href=\".\\dbinfo.html\">查看数据库情况</a>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
